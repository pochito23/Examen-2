<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title', 'Panel') - {{ config('app.name') }}</title>

<link rel="icon" href="{{ asset('assets/images/favicon.ico') }}">
<link rel="stylesheet" href="{{ asset('assets/libs/bootstrap/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/libs/bootstrap-icons/bootstrap-icons.css') }}">
<link rel="stylesheet" href="{{ asset('assets/libs/apexcharts/apexcharts.css') }}">
<link rel="stylesheet" href="{{ asset('assets/libs/flatpickr/flatpickr.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/css/main.css') }}">
@stack('styles')
</head>
<body>

@include('partials.sidebar')

<div class="main-wrapper">

    @include('partials.navbar')

    <div class="page-header">
        <div>
            <h1 class="page-title">@yield('title', 'Panel')</h1>
            <p class="page-subtitle">@yield('subtitle')</p>
        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item">
                    <a href="{{ route('dashboard') }}" class="text-decoration-none text-muted-green">Inicio</a>
                </li>
                <li class="breadcrumb-item active text-main" aria-current="page">@yield('title')</li>
            </ol>
        </nav>
    </div>

    @yield('content')

    @include('partials.footer')

</div>

<script src="{{ asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('assets/libs/apexcharts/apexcharts.min.js') }}"></script>
<script src="{{ asset('assets/libs/flatpickr/flatpickr.min.js') }}"></script>
<script src="{{ asset('assets/js/dashboard.js') }}"></script>
@stack('scripts')
</body>
</html>
