@extends('layouts.admin')

@section('title', 'Dashboard')
@section('subtitle', 'Resumen general')

@section('content')
    {{-- Aquí pegas las cards, gráficas, etc. de index.html --}}
@endsection
